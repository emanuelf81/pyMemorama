/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import com.example.gui.JDCalificar;
import com.example.gui.JDLoginUsuario;

/**
 *
 * @author Emanuel
 */
public class Ejecutable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //JFPrincipal p = new JFPrincipal();
        JDLoginUsuario jdl = new JDLoginUsuario(null, true);
        //JDCalificar jdc = new JDCalificar(null, false, null);
    }

}
